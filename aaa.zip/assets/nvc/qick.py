import os
import json
import argparse

def generate_json_files(textures_dir, items_dir, models_dir):
    """生成JSON文件"""
    
    # 确保输出目录存在
    os.makedirs(items_dir, exist_ok=True)
    os.makedirs(models_dir, exist_ok=True)
    
    # 支持的图片格式
    image_extensions = {'.png', '.jpg', '.jpeg', '.tga', '.bmp'}
    
    # 计数器
    files_processed = 0
    
    # 遍历textures/item目录下的所有子目录
    for root, dirs, files in os.walk(textures_dir):
        for filename in files:
            # 检查是否为图片文件
            if any(filename.lower().endswith(ext) for ext in image_extensions):
                # 获取文件名（不含扩展名）
                name_without_ext = os.path.splitext(filename)[0]
                
                # 计算相对路径（相对于textures_dir）
                relative_path = os.path.relpath(root, textures_dir)
                
                # 如果文件在textures/item根目录，relative_path会是"."，我们需要处理这种情况
                if relative_path == ".":
                    texture_path = f"nvc:item/{name_without_ext}"
                else:
                    texture_path = f"nvc:item/{relative_path}/{name_without_ext}"
                
                # 生成items目录下的JSON文件
                items_json = {
                    "model": {
                        "type": "minecraft:model",
                        "model": f"{texture_path}"
                    }
                }
                
                # 生成models/item目录下的JSON文件
                models_json = {
                    "parent": "minecraft:item/generated",
                    "textures": {
                        "layer0": f"{texture_path}"
                    }
                }
                
                # 确定输出子目录
                if relative_path == ".":
                    items_subdir = items_dir
                    models_subdir = models_dir
                else:
                    items_subdir = os.path.join(items_dir, relative_path)
                    models_subdir = os.path.join(models_dir, relative_path)
                
                # 确保输出子目录存在
                os.makedirs(items_subdir, exist_ok=True)
                os.makedirs(models_subdir, exist_ok=True)
                
                # 写入items目录的JSON文件
                items_file_path = os.path.join(items_subdir, f"{name_without_ext}.json")
                with open(items_file_path, 'w', encoding='utf-8') as f:
                    json.dump(items_json, f, indent=2, ensure_ascii=False)
                
                # 写入models/item目录的JSON文件
                models_file_path = os.path.join(models_subdir, f"{name_without_ext}.json")
                with open(models_file_path, 'w', encoding='utf-8') as f:
                    json.dump(models_json, f, indent=2, ensure_ascii=False)
                
                files_processed += 1
                print(f"✓ 已处理: {os.path.join(relative_path, filename)} -> {texture_path}")
    
    return files_processed

def main():
    parser = argparse.ArgumentParser(description='为纹理图片生成JSON配置文件')
    parser.add_argument('--textures', default='textures/item', 
                       help='纹理图片根目录路径 (默认: textures/item)')
    parser.add_argument('--items', default='items', 
                       help='items JSON文件输出目录 (默认: items)')
    parser.add_argument('--models', default='models/item', 
                       help='models JSON文件输出目录 (默认: models/item)')
    
    args = parser.parse_args()
    
    # 检查纹理目录是否存在
    if not os.path.exists(args.textures):
        print(f"错误: 找不到纹理目录 '{args.textures}'")
        print("请检查路径或使用 --textures 参数指定正确的路径")
        return
    
    print(f"纹理目录: {args.textures}")
    print(f"Items输出: {args.items}")
    print(f"Models输出: {args.models}")
    print("-" * 50)
    
    # 生成JSON文件
    files_count = generate_json_files(args.textures, args.items, args.models)
    
    print("-" * 50)
    if files_count > 0:
        print(f"✓ 完成! 共处理 {files_count} 个图片文件")
        print(f"✓ Items JSON文件保存在: {args.items}")
        print(f"✓ Models JSON文件保存在: {args.models}")
    else:
        print("⚠ 未找到任何图片文件")
        print("支持的格式: .png, .jpg, .jpeg, .tga, .bmp")

if __name__ == "__main__":
    main()